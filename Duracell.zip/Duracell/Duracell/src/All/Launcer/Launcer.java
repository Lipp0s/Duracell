package All.Launcer;

import All.CoinFilps.game.Menu;
import All.DueMilaQuarantotto.DueMilaQuarantotto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Launcer extends JFrame {
    private JPanel panell;
    private JLabel titleLabel;
    private JButton button1;
    private JButton button2;

    public Launcer() {
        // Imposta l'icona del frame
        String iconPath = "Duracell/src/All/Launcer/res/launcer.png";
        ImageIcon icon = new ImageIcon(iconPath);
        if (icon.getImageLoadStatus() == MediaTracker.COMPLETE) {
            setIconImage(icon.getImage());
        } else {
            System.err.println("Icona non trovata: " + iconPath);
        }

        setSize(1300, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panell);
        setVisible(true);

        button1.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 253, 170), 2), // Bordo esterno
                BorderFactory.createLineBorder(new Color(255, 253, 170), 2)  // Bordo interno
        ));
        button2.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 253, 170), 2), // Bordo esterno
                BorderFactory.createLineBorder(new Color(255, 253, 170), 2)  // Bordo interno
        ));

        button1.addActionListener(new ActionListener() {   // bottone 1 cliccato = apre Coin Filps
            @Override
            public void actionPerformed(ActionEvent e) {
                setState(JFrame.ICONIFIED);
                Menu menu = new Menu();
            }
        });
        button2.addActionListener(new ActionListener() {   // bottone 2 cliccato, apre DUEMILA48
            @Override
            public void actionPerformed(ActionEvent e) {  // DUEMILA48 non ha un frame. percio' va creato prima di aprirlo
                setState(JFrame.ICONIFIED);
                DueMilaQuarantotto game2048 = new DueMilaQuarantotto();
                JFrame frame2048 = new JFrame("DUEMILA48");
                frame2048.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame2048.add(game2048);
                frame2048.pack();
                frame2048.setLocationRelativeTo(null);
                frame2048.setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        Launcer launcer = new Launcer();
    }
}
