package All.DueMilaQuarantotto;

import javax.swing.*;
import java.awt.*;

public class GameFrame extends JFrame {
    private DueMilaQuarantotto gamePanel;

    public GameFrame() {
        setTitle("DUEMILA48");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);

        gamePanel = new DueMilaQuarantotto();
        setLayout(new BorderLayout());
        add(gamePanel, BorderLayout.CENTER);
        pack();
    }

    public DueMilaQuarantotto getGamePanel() {
        return gamePanel;
    }
}