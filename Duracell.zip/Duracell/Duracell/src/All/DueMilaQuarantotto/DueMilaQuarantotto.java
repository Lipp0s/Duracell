package All.DueMilaQuarantotto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class DueMilaQuarantotto extends JPanel implements KeyListener {
    private static final int SIZE = 4;
    private int[][] board;
    private boolean won, lost;
    private boolean moved;
    private boolean transitioning;
    private Timer timer;

    public DueMilaQuarantotto() {
        board = new int[SIZE][SIZE];

        setPreferredSize(new Dimension(400, 400));
        setFocusable(true);
        addKeyListener(this);
        resetGame();
        setDoubleBuffered(true);

        //Esegue l'azione solo dopo la fine del timer
        timer = new Timer(85, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                transitioning = false;
                repaint();
                timer.stop();
            }
        });
    }

    private void resetGame() {
        board = new int[SIZE][SIZE];
        won = false;
        lost = false;
        addRandomTile();
        addRandomTile();
        moved = false;
    }

    private void addRandomTile() {
        Random rand = new Random();
        int x, y;
        do {
            x = rand.nextInt(SIZE);
            y = rand.nextInt(SIZE);
        } while (board[x][y] != 0);
        board[x][y] = rand.nextInt(10) == 0 ? 4 : 2;
    }

    private void moveTiles(int dx, int dy) {
        moved = false;
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                int x = dx == 1 ? SIZE - 1 - i : i;
                int y = dy == 1 ? SIZE - 1 - j : j;
                if (board[x][y] != 0) {
                    int nx = x + dx, ny = y + dy;
                    while (nx >= 0 && ny >= 0 && nx < SIZE && ny < SIZE && board[nx][ny] == 0) {
                        board[nx][ny] = board[x][y];
                        board[x][y] = 0;
                        x = nx;
                        y = ny;
                        nx += dx;
                        ny += dy;
                        moved = true;
                    }
                    if (nx >= 0 && ny >= 0 && nx < SIZE && ny < SIZE && board[nx][ny] == board[x][y]) {
                        board[nx][ny] *= 2;
                        board[x][y] = 0;
                        moved = true;
                        if (board[nx][ny] == 2048) {
                            won = true;
                        }
                    }
                }
            }
        }
        if (moved) {
            addRandomTile();
            if (!canMove()) {
                lost = true;
            }
        }
    }

    private boolean canMove() {
        for (int x = 0; x < SIZE; x++) {
            for (int y = 0; y < SIZE; y++) {
                if (board[x][y] == 0) return true;
                if (x < SIZE - 1 && board[x][y] == board[x + 1][y]) return true;
                if (y < SIZE - 1 && board[x][y] == board[x][y + 1]) return true;
            }
        }
        return false;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(0, 0, getWidth(), getHeight());
        for (int x = 0; x < SIZE; x++) {
            for (int y = 0; y < SIZE; y++) {
                drawTile(g, x, y);
            }
        }
        if (won || lost) {
            g.setColor(new Color(255, 255, 255, 200));
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.BOLD, 48));
            if (won) {
                g.drawString("You win!", 100, 200);
            } else {
                g.drawString("Game over!", 70, 200);
            }
        }
    }

    private void drawTile(Graphics g, int x, int y) {
        int value = board[x][y];
        int tileSize = getWidth() / SIZE;
        int tileX = x * tileSize;
        int tileY = y * tileSize;
        g.setColor(getTileColor(value));
        g.fillRoundRect(tileX, tileY, tileSize, tileSize, 10, 10);
        g.setColor(getTextColor(value));
        g.setFont(new Font("Arial", Font.BOLD, 24));
        String s = String.valueOf(value);
        FontMetrics fm = g.getFontMetrics();
        int textWidth = fm.stringWidth(s);
        int textHeight = fm.getAscent();
        if (value != 0) {
            g.drawString(s, tileX + (tileSize - textWidth) / 2, tileY + (tileSize + textHeight) / 2 - 4);
        }
    }

    private Color getTileColor(int value) {
        switch (value) {
            case 2: return new Color(0xEEE4DA);
            case 4: return new Color(0xEDE0C8);
            case 8: return new Color(0xF2B179);
            case 16: return new Color(0xF59563);
            case 32: return new Color(0xF67C5F);
            case 64: return new Color(0xF65E3B);
            case 128: return new Color(0xEDCF72);
            case 256: return new Color(0xEDCC61);
            case 512: return new Color(0xEDC850);
            case 1024: return new Color(0xEDC53F);
            case 2048: return new Color(0xEDC22E);
            case 4096: return new Color(0x3C3A32);
            case 8192: return new Color(0x3E3933);
            case 16384: return new Color(0x3F3B34);
            case 65536: return new Color(0x423F36);
        }
        return new Color(0xBBADA0);
    }

    private Color getTextColor(int value) {
        return value < 16 ? new Color(0x776E65) : new Color(0xF9F6F2);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (won || lost || transitioning) {
            return;
        }
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                moveTiles(-1, 0);
                break;
            case KeyEvent.VK_RIGHT:
                moveTiles(+1, 0);
                break;
            case KeyEvent.VK_UP:
                moveTiles(0, -1);
                break;
            case KeyEvent.VK_DOWN:
                moveTiles(0, +1);
                break;
        }
        if (moved) {
            transitioning = true;
            timer.start();
        } else {
            repaint();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) {}
}