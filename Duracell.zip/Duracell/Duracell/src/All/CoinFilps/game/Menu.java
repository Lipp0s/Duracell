package All.CoinFilps.game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Menu extends JFrame {
    private JPanel menuPanel;
    private JButton startButton;
    private JButton randomButton;
    private JButton quitButton;
    private JComboBox<String> difficultyBox;

    public Menu() {
        setContentPane(menuPanel);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setTitle("Coin Filps");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setVisible(true);

        startButton.setFocusPainted(false);
        randomButton.setFocusPainted(false);
        quitButton.setFocusPainted(false);

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Game game = new Game();
                Menu.this.setVisible(false);
                game.setVisible(true);
            }
        });

        randomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Random random = new Random();
                double randomPercentage = random.nextDouble() * 100; // Genera un numero casuale tra 0 e 100
                Game game = new Game(randomPercentage); // Passa la percentuale casuale al costruttore di Game
                Menu.this.setVisible(false);
                game.setVisible(true);
            }
        });

        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        new Menu();
    }
}