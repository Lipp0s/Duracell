package All.CoinFilps.game;

import javax.swing.*;
import java.awt.*;
import java.awt.Menu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Game extends JFrame {
    private JPanel screenPanel;
    private JButton backButton;
    private JButton headButton;
    private JButton tailButton;
    private JPanel bottomPanel;
    private JButton quitButton;
    private JPanel leftPanel;
    private JLabel fichesLabel;
    private JLabel gifLabel;
    private JLabel betLabel;
    private JLabel percLabel;
    private Timer timer;
    private ImageIcon gifIcon = new ImageIcon("Duracell/src/All/CoinFilps/res/coin.gif");
    private int fiches = 400;
    private int bet = 0;
    private int bets = 0;

    public Game() {
        this(100);
    }

    public Game(double initialPercentage) {
        setContentPane(screenPanel);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setTitle("Coin Flips");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setVisible(true);

        fichesLabel.setText("Fiches: " + fiches);
        fichesLabel.setFont(new Font("Arial", Font.BOLD, 19));
        betLabel.setText("Bet: " + bet);
        betLabel.setFont(new Font("Arial", Font.BOLD, 19));
        percLabel.setFont(new Font("Arial", Font.BOLD, 19));
        setPercentage(initialPercentage);


        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JMenu menu = new JMenu("Menu");
                Game.this.setVisible(false);
                menu.setVisible(true);
            }
        });

        headButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tailButton.setEnabled(false);
                showBetDialog("Head");
                tailButton.setEnabled(true);
            }
        });

        tailButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                headButton.setEnabled(false);
                showBetDialog("Tail");
                headButton.setEnabled(true);
            }
        });
    }

    public void setPercentage(double percentage) {
        percLabel.setText(String.format("%.2f%%", percentage));
    }

    private void showBetDialog(String choice) {
        JDialog betDialog = new JDialog(this, "Place your bet", true);
        betDialog.setSize(300, 200);
        betDialog.setLayout(new BorderLayout());
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2));

        JLabel betLabel = new JLabel("Enter your bet: ");
        JTextField betField = new JTextField();
        JButton allInButton = new JButton("All In");
        JButton halfButton = new JButton("Half");
        JButton submitButton = new JButton("Submit");
        JButton cancelButton = new JButton("Cancel");

        inputPanel.add(betLabel);
        inputPanel.add(betField);
        inputPanel.add(allInButton);
        inputPanel.add(halfButton);
        inputPanel.add(submitButton);
        inputPanel.add(cancelButton);

        betDialog.add(inputPanel, BorderLayout.CENTER);
        allInButton.addActionListener(e -> betField.setText(String.valueOf(fiches)));
        halfButton.addActionListener(e -> betField.setText(String.valueOf(fiches / 2)));
        submitButton.addActionListener(e -> {
            try {
                bets = Integer.parseInt(betField.getText());
                if (bets < 10 || bets > fiches) {
                    JOptionPane.showMessageDialog(betDialog, "Error: re-enter your bet");
                } else {
                    betDialog.dispose();
                    processBet(choice);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(betDialog, "Invalid input. Please enter a valid number.");
            }
        });
        cancelButton.addActionListener(e -> betDialog.dispose());

        betDialog.setLocationRelativeTo(this);
        betDialog.setVisible(true);
    }

    private void processBet(String choice) {
        betLabel.setText("Bet: " + bets);
        fichesLabel.setText("Fiches: " + (fiches - bets));
        quitButton.setEnabled(false);
        gifLabel.setIcon(gifIcon);
        screenPanel.repaint();

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                gifLabel.setIcon(null);
                String percentString = percLabel.getText().replace("%", "").replace(",", ".");
                double percentage = Double.parseDouble(percentString) / 100.0;
                double random = Math.random();
                String result;
                if (random < percentage) {
                    result = choice;
                } else {
                    result = choice.equals("Head") ? "Tail" : "Head";
                }
                JOptionPane.showMessageDialog(null, "Coin landed on: " + result);
                if (result.equals(choice)) {
                    adjustPercentageAndFiches(0.5, 4.5, true, "down");
                } else {
                    adjustPercentageAndFiches(0.5, 20.5, false, "up");
                }
                quitButton.setEnabled(true);
            }
        }, 3500);
    }

    private void adjustPercentageAndFiches(double min, double max, boolean win, String mammahotantapaura) {
        Random rand = new Random();
        double randomValue = min + (max - min) * rand.nextDouble();
        String percentString = percLabel.getText().replace("%", "").replace(",", ".");
        double percentage = Double.parseDouble(percentString) / 100.0;
        if (percentage < 0) {
            percentage = 0;
        }
        else if (percentage > 100) {
            percentage = 100;
        }
        if (mammahotantapaura.equalsIgnoreCase("up")){
            percentage += randomValue / 100.0;
        }
        else percentage-=randomValue / 100.0;
        percLabel.setText(String.format("%.2f%%", percentage * 100));
        percLabel.setFont(new Font("Arial", Font.BOLD, 19));

        if (win) {
            fiches += bets;
        } else {
            fiches -= bets;
        }
        fichesLabel.setText("Fiches: " + fiches);
        bets = 0;
        betLabel.setText("Bet: " + bets);
    }
}